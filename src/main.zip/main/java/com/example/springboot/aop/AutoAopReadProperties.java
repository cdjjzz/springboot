package com.example.springboot.aop;

import org.aspectj.weaver.tools.PointcutExpression;
import org.springframework.aop.ClassFilter;
import org.springframework.aop.MethodMatcher;
import org.springframework.aop.Pointcut;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.config.AopConfigUtils;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import org.thymeleaf.spring5.context.SpringContextUtils;

@Configuration
@EnableConfigurationProperties({AopReadProperties.class})
public class AutoAopReadProperties implements BeanPostProcessor, PriorityOrdered {


    private AopReadProperties aopReadProperties;

    public AutoAopReadProperties(){

    }

    public AutoAopReadProperties(AopReadProperties aopReadProperties){
        this.aopReadProperties=aopReadProperties;
    }
    @Override
    public Object postProcessBeforeInitialization(Object bean, String s) throws BeansException {
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(bean);
        aopReadProperties=new AopReadProperties();
        aopReadProperties.setExpression("execution(* com.example.springboot.Dao.*.*(..))");
        factory.addAdvisor(new AopAdvice(aopReadProperties));
        return factory.getProxy();
    }

    @Override
    public int getOrder() {
        return -111111111;
    }
}
