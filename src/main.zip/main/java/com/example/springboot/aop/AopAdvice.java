package com.example.springboot.aop;

import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.weaver.loadtime.Aj;
import org.aspectj.weaver.tools.PointcutExpression;
import org.springframework.aop.Pointcut;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.AopUtils;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.core.PriorityOrdered;

public class AopAdvice extends DefaultPointcutAdvisor{

    private AopReadProperties aopReadProperties;

    public AopAdvice(AopReadProperties aopReadProperties){
        this.aopReadProperties=aopReadProperties;
    }
    @Override
    public Pointcut getPointcut() {
        AspectJExpressionPointcut aspectJExpressionPointcut=new AspectJExpressionPointcut();
        aspectJExpressionPointcut.setPointcutDeclarationScope(LogAop.class);
        aspectJExpressionPointcut.setExpression(aopReadProperties.getExpression());
        PointcutExpression pointcutExpression=aspectJExpressionPointcut.getPointcutExpression();
        String  ex=pointcutExpression.getPointcutExpression();
        //AopUtils.canApply(aspectJExpressionPointcut, LogAop.class);
        return aspectJExpressionPointcut;
    }

    @Override
    public Advice getAdvice() {
        return super.getAdvice();
    }
}
